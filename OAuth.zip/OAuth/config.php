<?php
	session_start();

	require_once "Facebook/autoload.php";
	
	//Replace the app_id,app_secret with yours.
	$FB = new \Facebook\Facebook([
		'app_id' => '2216965171922262',
		'app_secret' => '68df0d0425e1b820150e6b1e224843a4',
		'default_graph_version' => 'v3.0'
	]);

	$helper = $FB->getRedirectLoginHelper();
?>
